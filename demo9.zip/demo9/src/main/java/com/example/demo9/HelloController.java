package com.example.demo9;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;

import java.sql.PreparedStatement;

public class HelloController {

    @FXML
    private Label welcomeText;

    @FXML
    private TableColumn<Product, String> tcname;

    @FXML
    private TableColumn<Product, Double> tcprice;

    @FXML
    private TableColumn<Product, Integer> tcquantity;

    @FXML
    private TableColumn<Product, String> tccat;

    @FXML
    private TextField tf1;

    @FXML
    private TextField tf2;

    @FXML
    private TextField tf3;

    @FXML
    private Spinner<Integer> sp;

    @FXML
    private ComboBox<category> cbox;

    @FXML
    private Label lstatus;

    @FXML
    private TableView<Product> table;

    private ObservableList<Product> productData =
            FXCollections.observableArrayList();

    private ObservableList<category> categoryData =
            FXCollections.observableArrayList();

    @FXML
    private void initialize() {

        // Kategórie
        categoryData.add(new category(1, "Electronics"));
        categoryData.add(new category(2, "Food"));
        categoryData.add(new category(3, "Clothes"));

        cbox.setItems(categoryData);

        // Spinner
        sp.setValueFactory(
                new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 1000, 1)
        );

        // Tabuľka
        table.setItems(productData);

        tcname.setCellValueFactory(c ->
                new ReadOnlyStringWrapper(c.getValue().getName()));

        tcprice.setCellValueFactory(c ->
                new ReadOnlyObjectWrapper<>(c.getValue().getPrice()));

        tcquantity.setCellValueFactory(c ->
                new ReadOnlyObjectWrapper<>(c.getValue().getQuantity()));

        tccat.setCellValueFactory(c ->
                new ReadOnlyStringWrapper(
                        c.getValue().getCategory().getName()
                ));
    }

    @FXML
    private void btadd() {

        try {
            int id = productData.size() + 1;
            String name = tf1.getText();
            double price = Double.parseDouble(tf2.getText());
            int quantity = sp.getValue();
            category cat = cbox.getValue();

            if (name.isEmpty() || cat == null) {
                lstatus.setText("Vyplň všetky údaje!");
                return;
            }

            Product p = new Product(id, name, price, quantity, cat);

            productData.add(p);

            lstatus.setText("Produkt bol pridaný!");

        } catch (NumberFormatException e) {
            lstatus.setText("Nesprávna cena!");
        }
    }

    @FXML
    private void btsave() {
        lstatus.setText("Údaje boli uložené!");
    }

    @FXML
    private void btdel() {

        Product selected = table.getSelectionModel().getSelectedItem();

        if (selected != null) {
            productData.remove(selected);
            lstatus.setText("Produkt bol vymazaný!");
        } else {
            lstatus.setText("Vyber produkt!");
        }
    }

    @FXML
    private void btref() {

        table.refresh();
        lstatus.setText("Tabuľka bola obnovená!");
    }
    @FXML
    private void btnSave(){}
    @FXML
    private void btnDel(){
        return;
        try(Connection con = DriverManager,getConnection(
                URL,USERNAME?PASSWORD);
        PreparedStatement ps = con.prepareStatement(
                sql:
        ))
    }
    @FXML
   public void add() {
    String sql = "INSERT INTO product (name, price, quantity, category_id, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())"
    }
    try (Connection con)
}